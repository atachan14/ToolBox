import importlib
import pkgutil
import tools


def load_tools():

    tools = {}

    for module in pkgutil.iter_modules(tools.__path__):

        try:
            mod = importlib.import_module(f"tabs.{module.name}.tool")
        except ModuleNotFoundError:
            continue

        tool = mod.Tab
        tools[tool.TOOL_NAME] = tool

    return dict(
    sorted(tools.items(), key=lambda x: x[1].TOOL_ORDER)
)