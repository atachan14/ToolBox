from PySide6.QtWidgets import (
    QMainWindow,
    QTabWidget,
    QWidget,
    QInputDialog,
    QTabBar
)

from PySide6.QtCore import QSettings
from core.new_tab import NewTab
from core.tool_loader import load_tools

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        
        self.tools = load_tools()

        self.settings = QSettings("toolbox", "toolbox")

        self.setWindowTitle("Toolbox")

        self.tabs = QTabWidget()
        self.tabs.setTabBar(FixedTabBar())
        self.tabs.tabBar().setMovable(True)
        self.tabs.setTabsClosable(True)
        
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.tabBarClicked.connect(self.handle_tab_click)

        self.setCentralWidget(self.tabs)

        self.add_plus_tab()
        
        # 前回のサイズを復元
        geometry = self.settings.value("geometry")
        if geometry:
            self.restoreGeometry(geometry)
        else:
            self.resize(400, 800)
        
        self.restore_tabs()

    def add_plus_tab(self):

        plus_tab = QWidget()

        index = self.tabs.addTab(plus_tab, "+")

        self.tabs.tabBar().setTabButton(
            index,
            QTabBar.ButtonPosition.RightSide,
            None
        )


    def handle_tab_click(self, index):

        if self.tabs.tabText(index) != "+":
            return

        self.open_new_tab()

    def open_new_tab(self):

        plus_index = self.tabs.count() - 1

        widget = NewTab(self)

        self.tabs.insertTab(plus_index, widget, "New")
        self.tabs.setCurrentIndex(plus_index)

    def close_tab(self, index):

        if self.tabs.tabText(index) == "+":
            return

        self.tabs.removeTab(index)
        
    def closeEvent(self, event):

        # window size
        self.settings.setValue("geometry", self.saveGeometry())

        # 開いてるツール保存
        open_tabs = []

        for i in range(self.tabs.count()):

            widget = self.tabs.widget(i)

            if hasattr(widget, "TOOL_NAME"):
                open_tabs.append(widget.TOOL_NAME)

        self.settings.setValue("open_tabs", open_tabs)

        super().closeEvent(event)
        
    def open_tool(self, tool_class, replace_widget=None):

        widget = tool_class()

        if replace_widget:
            index = self.tabs.indexOf(replace_widget)

            self.tabs.removeTab(index)
            self.tabs.insertTab(index, widget, tool_class.TOOL_LABEL)
            self.tabs.setCurrentIndex(index)

        else:
            plus_index = self.tabs.count() - 1

            self.tabs.insertTab(plus_index, widget, tool_class.TOOL_LABEL)
            self.tabs.setCurrentIndex(plus_index)

    def restore_tabs(self):

        saved = self.settings.value("open_tabs", [], type=list)

        if not saved:
            return

        for tool_name in saved:

            tool_class = self.tools.get(tool_name)

            if tool_class:
                self.open_tool(tool_class)
                
class FixedTabBar(QTabBar):

    def mousePressEvent(self, event):

        index = self.tabAt(event.pos())

        if index >= 0 and self.tabText(index) == "+":
            QTabBar.mousePressEvent(self, event)
            return

        super().mousePressEvent(event)