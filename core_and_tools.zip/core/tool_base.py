from PySide6.QtWidgets import QWidget


class ToolBase(QWidget):

    TOOL_NAME = "tool"
    TOOL_LABEL = "Tool"
    TOOL_ORDER = 100

    def __init__(self):
        super().__init__()